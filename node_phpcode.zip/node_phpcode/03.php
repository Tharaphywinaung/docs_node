<?php
$time = strtotime(date("Y-m-d G:m:i", strtotime('+2 hours')));
$start = strtotime(date('Y-m-d G:m:i'));
$end = strtotime(date("Y-m-d G:59:59", strtotime('+23 hours')));

If ($start < $end) {
	  
   $time_result = date('h',$time);
   $start_result = date('h',$start);
   $end_result = date('h',$end);
  
  If (($time >= $start && $time < $end) ||
  ($time = $start && $time = $end)) {

    $result = $time_result ."は".$start_result."から".$end_result."に含まれます。";   
  }else {
    $result = $time_result."は".$start_result."から".$end_result."に含まれません。";  
  } 
  echo $result;
  Return $result;
}
