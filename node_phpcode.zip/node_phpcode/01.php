<?php

$card ="1234567891011213";
$card = str_split($card);
For( $i = 0; $i < 16; $i++ ){
  $NSum = 0;
  If( $i % 2 == 0 ) {    
    $N =$card[$i]*2;

    If($N > 9){
        $N1 = $N – 10;
        $N2 = $N / 10;
        $N = $N1 + $N2;

      }
  }
    $NSum += $N;
$X = (10 - $NSum % 10) % 10;
Echo ("a_".$X ."<br>");
Return "a_".$X."<br>";
}
