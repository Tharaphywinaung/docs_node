<?php
$n = 8;
$coin = "wwbwbbwb";
If($n < 9){
  Echo substr_count($coin, 'b');
}
?>
